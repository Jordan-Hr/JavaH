/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */

package PracticaJavaJhiraldo18;
public class Empleado extends Persona{


    private String Cargo;
    private String Experiencia;

    public Empleado(String nombre, int edad, String localidad, int cedula) {
        super(nombre, edad, localidad, cedula);
    }

    public void  solicitudPermiso(){
        System.out.println("El empleado solicitó un permiso");
    }

    public void ReporteHorasExtra(){
        System.out.println("Se reportaron las horas de trabajo");
    }


}


