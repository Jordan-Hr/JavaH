/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PracticaJavaJhiraldo18;
/**
 *
 * @author User
 */

public class Cliente extends Persona{

    public Cliente(String nombre, int edad, String localidad, int cedula) {
        super(nombre, edad, localidad, cedula);
    }

    //metodos//
    public void ContactarRepresentante(){
        System.out.println("te has contactado con un representante ");
    }

    public void SolicitarInoformación() {
        System.out.println("has solicitado informacion");
    }


}